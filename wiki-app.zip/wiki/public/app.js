const $ = s => document.querySelector(s);
const LOGO = '<svg viewBox="0 0 64 64" width="SZ" height="SZ"><ellipse cx="22" cy="17" rx="7" ry="15" fill="#9B7BFF"/><ellipse cx="22" cy="18" rx="3.2" ry="10" fill="#fff"/><ellipse cx="42" cy="17" rx="7" ry="15" fill="#9B7BFF"/><ellipse cx="42" cy="18" rx="3.2" ry="10" fill="#fff"/><circle cx="32" cy="42" r="18" fill="#fff" stroke="#9B7BFF" stroke-width="3"/><circle cx="25" cy="40" r="2.6" fill="#7C5CFF"/><circle cx="39" cy="40" r="2.6" fill="#7C5CFF"/><ellipse cx="32" cy="46" rx="3" ry="2.2" fill="#B9A2FF"/><circle cx="21" cy="47" r="3" fill="#EFE9FF"/><circle cx="43" cy="47" r="3" fill="#EFE9FF"/></svg>';
$('#lg').innerHTML = LOGO.replace(/SZ/g, 110); $('#lg2').innerHTML = LOGO.replace(/SZ/g, 38);
const ld = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } };
const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
let me = ld('wk_me', null), friends = ld('wk_f', []), stk = ld('wk_s', []), msgs = {}, cur = null, img = null, emo = '🐰', bg = '#B9A2FF';
const cu = s => s.trim().replace(/^@/, '').replace(/\s+/g, '').toLowerCase();
const post = (url, o) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) }).then(async r => ({ ok: r.ok, d: await r.json() }));

async function login(n, u, t) {
  try {
    const r = await post('/api/login', { name: n, username: u, token: t });
    if (!r.ok) { $('#err').textContent = r.d.error; return; }
    me = { n: r.d.name, u: r.d.username, t: r.d.token }; sv('wk_me', me); enter();
  } catch (e) { $('#err').textContent = 'ما كدرت أتصل بالسيرفر'; }
}
$('#go').onclick = () => { const n = $('#nm').value.trim(), u = cu($('#us').value); if (!n || !u) { $('#err').textContent = 'اكتب الاسم واسم المستخدم'; return; } login(n, u, me && me.u === u ? me.t : ''); };
if (me) { $('#nm').value = me.n; $('#us').value = me.u; login(me.n, me.u, me.t); }

function enter() { $('#login').style.display = 'none'; $('#app').style.display = 'flex'; $('#who').textContent = me.n + ' @' + me.u; lists(); gal(); draw(); connect(); }
function connect() {
  const es = new EventSource('/api/events?u=' + encodeURIComponent(me.u) + '&t=' + encodeURIComponent(me.t));
  es.onopen = () => { $('#note').style.display = 'none'; };
  es.onerror = () => { $('#note').style.display = 'block'; };
  es.onmessage = e => { const d = JSON.parse(e.data); (Array.isArray(d) ? d : [d]).forEach(m => msgs[m.id] = m); show(); lists(); };
}
document.querySelectorAll('nav button').forEach(b => b.onclick = () => { document.querySelectorAll('nav button').forEach(x => x.classList.toggle('on', x === b)); $('#t0').style.display = b.dataset.t === '0' ? '' : 'none'; $('#t1').style.display = b.dataset.t === '1' ? '' : 'none'; });
const key = u => [me.u, u].sort().join('|');
function lists() {
  const set = new Set(friends);
  Object.values(msgs).forEach(m => { if (m.c !== 'all') m.p.forEach(x => { if (x !== me.u) set.add(x); }); });
  const f = $('#fl'); f.innerHTML = '';
  [...set].forEach(u => { const b = document.createElement('button'); b.className = 'item'; b.innerHTML = '<div class="av"></div><div><span></span><i>محادثة خاصة</i></div>'; b.querySelector('.av').textContent = u[0].toUpperCase(); b.querySelector('span').textContent = '@' + u; b.onclick = () => openChat(key(u), '@' + u); f.appendChild(b); });
}
$('#pub').onclick = () => openChat('all', 'الغرفة العامة');
$('#fa').onclick = async () => {
  const u = cu($('#fu').value); if (!u || u === me.u) return;
  const r = await fetch('/api/user?u=' + encodeURIComponent(u)).then(r => r.json());
  if (!r.exists) { alert('هذا المستخدم غير موجود'); return; }
  if (!friends.includes(u)) { friends.push(u); sv('wk_f', friends); }
  $('#fu').value = ''; lists();
};
function openChat(c, t) { cur = c; $('#ct').textContent = t; $('#chat').style.display = 'flex'; $('#tray').style.display = 'none'; show(); }
$('#bk').onclick = () => { cur = null; $('#chat').style.display = 'none'; };
function show() {
  if (!cur) return; const box = $('#msgs'); box.innerHTML = '';
  Object.values(msgs).filter(m => m.c === cur).sort((a, b) => a.t - b.t).forEach(m => {
    const d = document.createElement('div'); d.className = 'm' + (m.u === me.u ? ' me' : '') + (m.s ? ' s' : '');
    if (m.u !== me.u) { const s = document.createElement('small'); s.textContent = m.n; d.appendChild(s); }
    if (m.s) { const i = document.createElement('img'); i.src = m.s; d.appendChild(i); } else d.appendChild(document.createTextNode(m.x));
    box.appendChild(d);
  });
  box.scrollTop = box.scrollHeight;
}
async function send(extra) {
  if (!cur) return;
  const to = cur === 'all' ? 'all' : cur.split('|').find(x => x !== me.u);
  try { const r = await post('/api/send', Object.assign({ username: me.u, token: me.t, to }, extra)); if (!r.ok) alert(r.d.error); } catch (e) { alert('فشل الإرسال'); }
}
$('#sd').onclick = () => { const v = $('#tx').value.trim(); if (!v) return; $('#tx').value = ''; send({ x: v }); };
$('#tx').onkeydown = e => { if (e.key === 'Enter') $('#sd').click(); };
$('#sb').onclick = () => {
  const t = $('#tray'); t.style.display = t.style.display === 'flex' ? 'none' : 'flex'; t.innerHTML = '';
  if (!stk.length) t.textContent = 'ما عندك ملصقات، سوّي واحد من تبويب الملصقات';
  stk.forEach(s => { const i = document.createElement('img'); i.src = s; i.onclick = () => { send({ s }); t.style.display = 'none'; }; t.appendChild(i); });
};
function gal() {
  const g = $('#gal'); g.innerHTML = '';
  stk.forEach((s, k) => { const d = document.createElement('div'); d.innerHTML = '<img><b>×</b>'; d.querySelector('img').src = s; d.querySelector('b').onclick = () => { stk.splice(k, 1); sv('wk_s', stk); gal(); }; g.appendChild(d); });
}
const cv = $('#cv'), cx = cv.getContext('2d');
function draw() {
  cx.clearRect(0, 0, 256, 256);
  cx.beginPath(); cx.roundRect(8, 8, 240, 240, 48); cx.fillStyle = '#fff'; cx.fill();
  cx.save(); cx.beginPath(); cx.roundRect(16, 16, 224, 224, 40); cx.clip(); cx.fillStyle = bg; cx.fillRect(0, 0, 256, 256);
  if (img) { const r = Math.max(256 / img.width, 256 / img.height); cx.drawImage(img, (256 - img.width * r) / 2, (256 - img.height * r) / 2, img.width * r, img.height * r); }
  cx.restore(); cx.textAlign = 'center'; cx.textBaseline = 'middle';
  if (emo) { cx.font = '110px serif'; cx.fillText(emo, 128, 110); }
  const t = $('#st').value;
  if (t) { cx.font = "800 34px Tajawal,Tahoma,sans-serif"; cx.lineWidth = 8; cx.strokeStyle = '#7C5CFF'; cx.lineJoin = 'round'; cx.strokeText(t, 128, 205, 200); cx.fillStyle = '#fff'; cx.fillText(t, 128, 205, 200); }
}
['🐰', '😂', '😍', '😎', '🥳', '😭', '👍', '❤️', '🔥', '✨'].forEach(e => { const b = document.createElement('button'); b.textContent = e; b.onclick = () => { emo = e; draw(); }; $('#em').appendChild(b); });
['#B9A2FF', '#4A7BFF', '#EFE9FF', '#9ED0FF', '#7C5CFF', '#FFD6E8'].forEach(c => { const b = document.createElement('button'); b.style.background = c; b.onclick = () => { bg = c; img = null; draw(); }; $('#cl').appendChild(b); });
$('#st').oninput = draw;
$('#im').onchange = e => { const f = e.target.files[0]; if (!f) return; const i = new Image(); i.onload = () => { img = i; emo = ''; draw(); }; i.src = URL.createObjectURL(f); };
$('#sv').onclick = () => { const o = document.createElement('canvas'); o.width = o.height = 200; o.getContext('2d').drawImage(cv, 0, 0, 200, 200); stk.unshift(o.toDataURL('image/webp', .8)); stk = stk.slice(0, 40); sv('wk_s', stk); gal(); };
